import { Component, computed, inject, signal, OnInit } from '@angular/core';
import { NgIf, NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';

import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';

import { QuestionnaireStore } from '../../data-access/questionnaire.store';
import type {
  Option,
  Question,
  JumpTarget,
} from '../../../../shared/models/questionnaire.model';

type AnswerValue =
  | { kind: 'text'; value: string }
  | { kind: 'date'; value: string } // yyyy-mm-dd
  | { kind: 'single'; optionId: string }
  | { kind: 'multi'; optionIds: string[] };

@Component({
  selector: 'app-questionnaire-fill',
  standalone: true,
  imports: [
    NgIf, NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault,
    MatButtonModule, MatCheckboxModule, MatRadioModule, MatIconModule, MatInputModule,
  ],
  templateUrl: './questionnaire-fill.component.html',
  styleUrls: ['./questionnaire-fill.component.scss'],
})
export class QuestionnaireFillComponent implements OnInit {
  readonly qs = inject(QuestionnaireStore);

  // 1) lista pitanja flatten (redoslijed sekcija + questionIds)
  readonly questionIds = computed<string[]>(() => {
    const secs = this.qs.sections();
    const map = this.qs.questionsById();
    const out: string[] = [];

    for (const s of secs) {
      for (const qid of s.questionIds ?? []) {
        if (map[qid]) out.push(qid);
      }
    }
    return out;
  });

  // 2) current question (ne koristimo index nego ID)
  readonly currentQuestionId = signal<string | null>(null);

  // history za "Nazad" (bitno kod grananja)
  readonly history = signal<string[]>([]);

  readonly currentQuestion = computed<Question | null>(() => {
    const id = this.currentQuestionId();
    if (!id) return null;
    return this.qs.questionsById()[id] ?? null;
  });

  readonly currentOptions = computed<Option[]>(() => {
    const q = this.currentQuestion();
    if (!q) return [];
    return this.qs.getOptionsForQuestion(q.id);
  });

  // 3) answers (lokalno)
  readonly answers = signal<Record<string, AnswerValue>>({});
  ngOnInit(): void {
    // init: prvo pitanje po redoslijedu
    const first = this.questionIds()[0] ?? null;
    this.currentQuestionId.set(first);
  }

  // helpers
  isFirst = computed(() => this.history().length === 0);

  // "last" u smislu: nema vise next pitanja
  isLast = computed(() => {
    const q = this.currentQuestion();
    if (!q) return true;

    const a = this.answers()[q.id];
    if (!a) return false; // dok ne odgovori, ne znamo “last”
    return this.resolveNextQuestionId(q, a) === null;
  });

  canGoNext = computed(() => {
    const q = this.currentQuestion();
    if (!q) return false;

    const a = this.answers()[q.id];
    if (!a) return false;

    if (q.type === 'short_text' || q.type === 'long_text') return a.kind === 'text';
    if (q.type === 'date') return a.kind === 'date';
    if (q.type === 'multiple_choice' || q.type === 'dropdown') return a.kind === 'single' && !!a.optionId;
    if (q.type === 'checkboxes') return a.kind === 'multi' && a.optionIds.length > 0;

    // document / ostalo: za sad true
    return true;
  });

  // ---------------------------------
  // NAVIGATION
  // ---------------------------------

  prev(): void {
    const h = this.history();
    if (!h.length) return;

    const prevId = h[h.length - 1];
    this.history.set(h.slice(0, -1));
    this.currentQuestionId.set(prevId);
  }

  next(): void {
    const q = this.currentQuestion();
    if (!q) return;

    const a = this.answers()[q.id];
    if (!a) return;

    const nextId = this.resolveNextQuestionId(q, a);
    if (!nextId) return; // kraj

    // push current u history i idi na next
    this.history.update((h) => [...h, q.id]);
    this.currentQuestionId.set(nextId);
  }

  // ---------------------------------
  // ANSWER SETTERS
  // ---------------------------------

  setText(value: string): void {
    const q = this.currentQuestion();
    if (!q) return;

    this.answers.update((m) => ({
      ...m,
      [q.id]: { kind: 'text', value } as const,
    }));
  }

  setDate(value: string): void {
    const q = this.currentQuestion();
    if (!q) return;

    this.answers.update((m) => ({
      ...m,
      [q.id]: { kind: 'date', value } as const,
    }));
  }

  setSingle(optionId: string): void {
    const q = this.currentQuestion();
    if (!q) return;

    this.answers.update((m) => ({
      ...m,
      [q.id]: { kind: 'single', optionId } as const,
    }));
  }

  toggleMulti(optionId: string, checked: boolean): void {
    const q = this.currentQuestion();
    if (!q) return;

    const cur = this.answers()[q.id];
    const existing = cur?.kind === 'multi' ? cur.optionIds : [];

    const next = checked
      ? Array.from(new Set([...existing, optionId]))
      : existing.filter((id) => id !== optionId);

    this.answers.update((m) => ({
      ...m,
      [q.id]: { kind: 'multi', optionIds: next } as const,
    }));
  }

  // read current answer
  getAnswer(): AnswerValue | null {
    const q = this.currentQuestion();
    if (!q) return null;
    return this.answers()[q.id] ?? null;
  }

  isChecked(optionId: string): boolean {
    const a = this.getAnswer();
    return a?.kind === 'multi' ? a.optionIds.includes(optionId) : false;
  }

  trackById(_: number, item: { id: string }) {
    return item.id;
  }

  private answerForCurrent(): AnswerValue | null {
    const q = this.currentQuestion();
    if (!q) return null;
    return this.answers()[q.id] ?? null;
  }

  singleOptionId(): string {
    const a = this.answerForCurrent();
    return a?.kind === 'single' ? a.optionId : '';
  }

  textValue(): string {
    const a = this.answerForCurrent();
    return a?.kind === 'text' ? a.value : '';
  }

  dateValue(): string {
    const a = this.answerForCurrent();
    return a?.kind === 'date' ? a.value : '';
  }

  // ---------------------------------
  // LOGIC: resolve next question
  // ---------------------------------

  /**
   * Default next po redoslijedu:
   * - sljedece pitanje u istoj sekciji
   * - ako je kraj sekcije, prvo pitanje sljedece sekcije koja ima pitanje
   * - null ako je kraj upitnika
   */
  private defaultNextQuestionId(currentId: string): string | null {
    const qMap = this.qs.questionsById();
    const questionnaire = this.qs.questionnaire();

    const current = qMap[currentId];
    if (!current) return null;

    const secIndex = questionnaire.sections.findIndex((s) => s.id === current.sectionId);
    if (secIndex < 0) return null;

    const sec = questionnaire.sections[secIndex];
    const idxInSec = (sec.questionIds ?? []).indexOf(currentId);

    // next u istoj sekciji
    if (idxInSec >= 0 && idxInSec + 1 < (sec.questionIds ?? []).length) {
      const nextId = sec.questionIds[idxInSec + 1];
      return qMap[nextId] ? nextId : null;
    }

    // prva pitanja iduce sekcije koja ima pitanje
    for (let i = secIndex + 1; i < questionnaire.sections.length; i++) {
      const s = questionnaire.sections[i];
      const first = (s.questionIds ?? []).find((id) => !!qMap[id]);
      if (first) return first;
    }

    return null;
  }

  /**
   * Conditional logic + fallback.
   * Ako postoji matching rule (single odgovor), skoci:
   * - na pitanje ili
   * - na prvu stavku u sekciji
   * Ako nema, idi default redoslijedom.
   */
  private resolveNextQuestionId(question: Question, answer: AnswerValue): string | null {
    // logic samo radi za single answer (multiple_choice / dropdown)
    if (answer.kind === 'single' && question.logic?.length) {
      const rule = question.logic.find((r) => r.whenOptionId === answer.optionId);

      if (rule?.jumpTo?.targetId) {
        const target = rule.jumpTo.targetId;

        if (rule.jumpTo.kind === 'question') {
          return this.qs.questionsById()[target] ? target : null;
        }

        if (rule.jumpTo.kind === 'section') {
          const sec = this.qs.sections().find((s) => s.id === target);
          const firstQ = (sec?.questionIds ?? [])[0];
          return firstQ && this.qs.questionsById()[firstQ] ? firstQ : null;
        }
      }
    }

    // fallback: standard next
    return this.defaultNextQuestionId(question.id);
  }
}
